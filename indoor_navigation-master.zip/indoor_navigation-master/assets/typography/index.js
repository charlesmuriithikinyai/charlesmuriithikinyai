export const colors = {
    mainColor: '#156504',
    red: '#ff0000',
    gold: '#CBD000',
    white: '#fff',
    gray: '#ddd',
    darkGray: '#525252',
};

export const fontSize = {
    large:30,
    medium:20,
    small:10
};
