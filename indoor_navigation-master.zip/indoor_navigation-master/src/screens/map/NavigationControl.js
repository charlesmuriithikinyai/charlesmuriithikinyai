import React from 'react';

const NavigationControl = (props) => {
    
}
