import React from 'react';
import { 
    StyleSheet, 
    View, 
    KeyboardAvoidingView, 
    Text,
    TouchableOpacity,
    Keyboard 
} from "react-native";


const DirectionsTab {
    return (
        <View >

        </View>
    )
}

const stles